import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { LayoutDashboard, Database, FileSearch, Building2, FileText, Settings, ShieldAlert, LogOut, Info, Download } from 'lucide-react';

const Layout = ({ children }) => (
  <div className="flex h-screen bg-slate-50 text-slate-900 font-sans">
    <div className="w-64 bg-slate-900 text-white flex flex-col shadow-xl z-10">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800">
        <ShieldAlert className="text-purple-400 w-8 h-8" />
        <h1 className="text-xl font-bold tracking-wider">Audit<span className="text-purple-400">IQ</span></h1>
      </div>
      <nav className="flex-1 px-4 py-6 space-y-2 overflow-auto">
        <NavItem to="/" icon={<Info size={20} />} label="Overview & Docs" />
        <NavItem to="/dashboard" icon={<LayoutDashboard size={20} />} label="Analytics Dashboard" />
        <NavItem to="/explorer" icon={<Database size={20} />} label="Data Explorer" />
        <NavItem to="/ingestion" icon={<Settings size={20} />} label="Data & Policy" />
        <NavItem to="/workspace" icon={<FileSearch size={20} />} label="Audit Workspace" />
        <NavItem to="/vendor" icon={<Building2 size={20} />} label="Vendor Intelligence" />
        <NavItem to="/reports" icon={<FileText size={20} />} label="Audit Reports" />
      </nav>
      <div className="p-4 border-t border-slate-800">
        <button className="flex items-center gap-3 text-slate-400 hover:text-white w-full px-4 py-2 rounded transition-colors">
          <Settings size={20} /> Settings
        </button>
        <button className="flex items-center gap-3 text-slate-400 hover:text-white w-full px-4 py-2 rounded transition-colors mt-2">
          <LogOut size={20} /> Logout
        </button>
      </div>
    </div>
    <div className="flex-1 flex flex-col overflow-hidden">
      <main className="flex-1 overflow-auto bg-slate-50 p-8">
        {children}
      </main>
    </div>
  </div>
);

const NavItem = ({ to, icon, label }) => (
  <NavLink 
    to={to} 
    className={({isActive}) => `flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${isActive ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30' : 'text-slate-300 hover:bg-slate-800 hover:text-white'}`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </NavLink>
);

const Card = ({ title, children, className = '' }) => (
  <div className={`bg-white rounded-xl shadow-sm border border-slate-200 p-6 ${className}`}>
    {title && <h3 className="text-lg font-semibold text-slate-800 mb-4">{title}</h3>}
    {children}
  </div>
);

const LandingPage = () => (
  <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
    <div className="bg-gradient-to-br from-slate-900 to-purple-900 rounded-3xl p-12 text-white shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"></div>
      <div className="relative z-10 max-w-2xl">
        <h1 className="text-5xl font-bold mb-6 leading-tight">Forensic-Grade Audit Analytics from Source Data</h1>
        <p className="text-xl text-purple-100 mb-8">ISA 230-aligned traceability, 100% population coverage, and proactive tax intelligence powered by a 7-agent decoupled microservice architecture.</p>
        <div className="flex gap-4">
           <button className="px-6 py-3 bg-purple-500 hover:bg-purple-400 text-white rounded-lg font-semibold transition-colors shadow-lg shadow-purple-500/30">Start Audit Workspace</button>
           <button className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-lg font-semibold transition-colors backdrop-blur-sm">View Documentation</button>
        </div>
      </div>
    </div>
    <div className="grid grid-cols-3 gap-6">
      <Card title="NIST AI RMF Compliant">
        <p className="text-slate-600">Built to satisfy rigorous AI Risk Management Framework standards with complete explainability.</p>
      </Card>
      <Card title="Tamper-Evident Logs">
        <p className="text-slate-600">Every AI action and human override is permanently logged with an immutable chain of evidence.</p>
      </Card>
      <Card title="No More Random Sampling">
        <p className="text-slate-600">Analyze 100% of your transactional data simultaneously using parallel LLM evaluation.</p>
      </Card>
    </div>
  </div>
);

const AnalyticsDashboard = () => (
  <div className="space-y-6 animate-in fade-in duration-500">
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-2xl font-bold text-slate-800">Command Center</h2>
      <div className="flex gap-2">
        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">All Systems Operational</span>
      </div>
    </div>
    
    <div className="grid grid-cols-5 gap-4">
      {[
        { label: "Transactions Screened", value: "1.2M", trend: "+12%" },
        { label: "High-Risk Exceptions", value: "342", trend: "-5%" },
        { label: "Financial Value at Risk", value: "$4.2M", trend: "+2%" },
        { label: "Dup. Payments Prevented", value: "$850K", trend: "+15%" },
        { label: "Policy Violation Rate", value: "2.4%", trend: "-0.5%" },
      ].map((k, i) => (
        <Card key={i} className="p-4">
          <p className="text-xs text-slate-500 font-medium whitespace-nowrap overflow-hidden text-ellipsis">{k.label}</p>
          <div className="flex items-end gap-2 mt-1">
            <h3 className="text-2xl font-bold text-slate-800">{k.value}</h3>
            <span className={`text-xs font-bold mb-1 ${k.trend.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>{k.trend}</span>
          </div>
        </Card>
      ))}
    </div>

    <Card title="Monthly Anomaly Trends (2026)" className="w-full">
      <div className="h-40 w-full flex items-end gap-2 px-2 mt-2">
        {[
          { month: "Jan", val: 35, anomalies: 12 },
          { month: "Feb", val: 42, anomalies: 15 },
          { month: "Mar", val: 55, anomalies: 22 },
          { month: "Apr", val: 48, anomalies: 18 },
          { month: "May", val: 65, anomalies: 28 },
          { month: "Jun", val: 50, anomalies: 20 },
          { month: "Jul", val: 75, anomalies: 35 },
          { month: "Aug", val: 68, anomalies: 30 },
          { month: "Sep", val: 85, anomalies: 42 },
          { month: "Oct", val: 72, anomalies: 32 },
          { month: "Nov", val: 90, anomalies: 48 },
          { month: "Dec", val: 40, anomalies: 15 },
        ].map((d, i) => (
          <div key={i} className="flex-1 flex flex-col justify-end items-center group relative cursor-pointer h-full">
             {/* Tooltip */}
             <div className="absolute -top-8 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                {d.anomalies} Anomalies ({d.val} Total)
             </div>
             {/* Bar */}
             <div className="w-full max-w-[40px] bg-purple-100 rounded-t-sm relative flex flex-col justify-end overflow-hidden group-hover:bg-purple-200 transition-colors" style={{ height: `${d.val}%` }}>
                <div className="w-full bg-purple-500 transition-all duration-500" style={{ height: `${(d.anomalies / d.val) * 100}%` }}></div>
             </div>
             <span className="text-[10px] text-slate-500 mt-2 font-medium uppercase tracking-wider">{d.month}</span>
          </div>
        ))}
      </div>
    </Card>

    <div className="grid grid-cols-3 gap-6">
      <div className="col-span-2 space-y-6 flex flex-col">
        <div className="grid grid-cols-2 gap-6 flex-1">
           <Card title="Vendor Risk Matrix" className="h-[280px] flex flex-col">
             <div className="flex-1 bg-slate-50 rounded border border-slate-200 flex items-center justify-center p-4 relative overflow-hidden">
                <div className="absolute w-12 h-12 rounded-full bg-red-400/50 top-1/4 left-1/4"></div>
                <div className="absolute w-16 h-16 rounded-full bg-orange-400/50 top-1/2 left-1/2"></div>
                <div className="absolute w-8 h-8 rounded-full bg-purple-400/50 bottom-1/4 right-1/4"></div>
                <p className="text-sm font-medium text-slate-400 z-10 bg-white/80 px-2 py-1 rounded">Interactive Bubble Chart Placeholder</p>
             </div>
           </Card>
           <Card title="Duplicate Invoice Clusters" className="h-[280px] flex flex-col">
             <div className="flex-1 space-y-3 overflow-auto">
               {[1,2,3].map(i => (
                 <div key={i} className="flex justify-between items-center p-3 bg-slate-50 rounded border border-slate-100 hover:border-slate-300 cursor-pointer transition-colors">
                    <div>
                      <p className="text-sm font-semibold text-slate-700">Cluster #{800+i}</p>
                      <p className="text-xs text-slate-500">{i+1} Similar Invoices detected</p>
                    </div>
                    <span className="text-sm font-bold text-red-600">${12*i},0{i}0</span>
                 </div>
               ))}
             </div>
           </Card>
        </div>
        <div className="grid grid-cols-2 gap-6 flex-1">
           <Card title="Risk Heat Map" className="h-[280px] flex flex-col">
              <div className="flex-1 grid grid-cols-3 grid-rows-3 gap-2">
                 {Array.from({length: 9}).map((_, i) => (
                   <div key={i} className={`rounded-lg ${i===4 ? 'bg-red-500' : i%2===0 ? 'bg-orange-300' : 'bg-green-200'} opacity-80 hover:opacity-100 transition-opacity cursor-pointer`}></div>
                 ))}
              </div>
           </Card>
           <Card title="Internal Compliance" className="h-[280px] flex flex-col justify-center items-center">
              <div className="flex items-center justify-center relative mt-4">
                 <svg className="w-40 h-40 transform -rotate-90">
                    <circle cx="80" cy="80" r="64" fill="none" stroke="#f1f5f9" strokeWidth="16" />
                    <circle cx="80" cy="80" r="64" fill="none" stroke="#22c55e" strokeWidth="16" strokeDasharray="402" strokeDashoffset="80" strokeLinecap="round" />
                 </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-bold text-slate-800">80%</span>
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-1">Pass Rate</span>
                 </div>
              </div>
           </Card>
        </div>
      </div>

      <div className="space-y-6 flex flex-col">
        <Card title="Proactive Tax Intelligence" className="bg-gradient-to-br from-purple-50 to-white border-purple-100">
          <div className="space-y-4">
             <div className="p-4 bg-white rounded-lg border border-purple-100 shadow-sm hover:shadow-md transition-shadow">
                <h4 className="text-sm font-bold text-purple-700 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  Missed Tax Credits
                </h4>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">Identified $1.1M in unclaimed ITC across 15 vendors due to mismatched HSN codes.</p>
                <button className="text-xs text-purple-600 font-bold mt-3 hover:text-purple-800 transition-colors">View Claim Report &rarr;</button>
             </div>
             <div className="p-4 bg-white rounded-lg border border-purple-100 shadow-sm hover:shadow-md transition-shadow">
                <h4 className="text-sm font-bold text-purple-700 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  Structural Insight
                </h4>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">Consolidating IT hardware purchases across Q1/Q2 could yield a 4% volume discount ($300k savings).</p>
                <button className="text-xs text-purple-600 font-bold mt-3 hover:text-purple-800 transition-colors">View Analysis &rarr;</button>
             </div>
          </div>
        </Card>
        <Card title="Urgent Escalations" className="flex-1 overflow-auto max-h-[260px]">
          <div className="space-y-3">
            {[1,2,3,4].map(i => (
               <div key={i} className="p-3 border border-slate-100 rounded-lg bg-slate-50 flex flex-col gap-1 hover:border-purple-200 transition-colors cursor-pointer">
                 <div className="flex justify-between items-center mb-1">
                   <span className="font-semibold text-sm text-slate-800">INV-2026-00{i}</span>
                   <span className="text-xs font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">Score: 9{i}</span>
                 </div>
                 <p className="text-xs text-slate-500 line-clamp-2">Vendor collision detected across multiple IP addresses...</p>
               </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  </div>
);

const AuditWorkspace = () => (
  <div className="h-full flex flex-col animate-in fade-in duration-500">
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-2xl font-bold text-slate-800">Unified Audit Workspace</h2>
    </div>
    
    <div className="flex-1 flex gap-6 min-h-0">
      {/* Left Panel: Queue */}
      <div className="w-80 flex flex-col gap-4 bg-white border border-slate-200 rounded-xl p-4 overflow-hidden shadow-sm">
        <h3 className="font-semibold text-slate-700">Review Queue</h3>
        <div className="relative">
          <input type="text" placeholder="Search exceptions..." className="w-full pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
          <FileSearch className="absolute left-2.5 top-2.5 text-slate-400" size={16} />
        </div>
        <div className="flex-1 overflow-auto space-y-2 pr-2">
          {[
            { id: "INV-9921", score: 98, vendor: "TechCorp Logistics" },
            { id: "PO-4412", score: 85, vendor: "Global Supplies Inc." },
            { id: "INV-1102", score: 81, vendor: "Apex Solutions" },
            { id: "GRN-0922", score: 75, vendor: "Prime Manufacturing" },
          ].map((item, i) => (
            <div key={i} className={`p-3 rounded-lg border cursor-pointer transition-colors ${i === 0 ? 'bg-purple-50 border-purple-200 shadow-sm' : 'bg-white border-slate-100 hover:border-slate-300'}`}>
               <div className="flex justify-between items-center mb-1">
                 <span className="font-semibold text-sm text-slate-800">{item.id}</span>
                 <span className={`text-xs font-bold px-2 py-0.5 rounded ${item.score > 90 ? 'text-red-700 bg-red-100' : 'text-orange-700 bg-orange-100'}`}>{item.score} Risk</span>
               </div>
               <p className="text-xs text-slate-500">{item.vendor}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main Panel */}
      <div className="flex-1 flex flex-col gap-4 min-h-0">
        
        {/* Explainable AI */}
        <Card className="flex-none bg-gradient-to-r from-purple-50 to-white border-purple-100">
          <h3 className="text-sm font-bold text-purple-700 mb-2 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
            AI Reasoning ("Why Flagged?")
          </h3>
          <p className="text-slate-700 text-sm leading-relaxed">
            The invoice amount of <strong>$45,000</strong> exceeds the associated PO-4412 limit of <strong>$40,000</strong>. Furthermore, the GSTIN profile for <em>TechCorp Logistics</em> indicates a "Suspended" status as of 2 days ago. <a href="#" className="text-purple-600 underline text-xs ml-1">[View DB Evidence]</a>
          </p>
        </Card>

        {/* 3-Way Match & Chain of Evidence */}
        <div className="flex-1 grid grid-rows-2 gap-4 min-h-0">
           <Card title="3-Way Match Overview" className="overflow-auto flex flex-col">
             <div className="flex-1 flex gap-4">
                <div className="flex-1 bg-slate-50 rounded border p-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Purchase Order</h4>
                  <div className="text-sm font-mono space-y-1 text-slate-600">
                    <p>ID: PO-4412</p>
                    <p>Total: $40,000</p>
                    <p>Status: Approved</p>
                  </div>
                </div>
                <div className="flex-1 bg-slate-50 rounded border p-4">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Goods Receipt (GRN)</h4>
                  <div className="text-sm font-mono space-y-1 text-slate-600">
                    <p>ID: GRN-881</p>
                    <p>Total: $40,000</p>
                    <p>Match: TRUE</p>
                  </div>
                </div>
                <div className="flex-1 bg-red-50 border-red-100 rounded border p-4">
                  <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider mb-2">Invoice</h4>
                  <div className="text-sm font-mono space-y-1 text-red-700">
                    <p>ID: INV-9921</p>
                    <p className="font-bold border-b border-red-200 inline-block">Total: $45,000</p>
                    <p>Match: FALSE</p>
                  </div>
                </div>
             </div>
           </Card>
           
           <Card title="Chain of Evidence (ISA 230)" className="overflow-auto">
             <div className="space-y-4">
                <div className="flex gap-4 items-start">
                  <div className="w-2 h-2 rounded-full bg-slate-300 mt-1.5 flex-none"></div>
                  <div>
                    <p className="text-sm text-slate-800 font-medium">Data Ingested via Kafka</p>
                    <p className="text-xs text-slate-500">2026-05-02 10:15:00 UTC</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <div className="w-2 h-2 rounded-full bg-purple-500 mt-1.5 flex-none"></div>
                  <div>
                    <p className="text-sm text-purple-900 font-medium">Flowise Agent 1 Evaluated Ruleset</p>
                    <p className="text-xs text-purple-600/70">2026-05-02 10:15:02 UTC</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start border-l-2 border-dashed border-slate-200 ml-1 pl-3 h-4 -my-3"></div>
                <div className="flex gap-4 items-start">
                  <div className="w-2 h-2 rounded-full bg-orange-500 mt-1.5 flex-none -ml-1"></div>
                  <div>
                    <p className="text-sm text-slate-800 font-medium">Escalated to HITL Queue</p>
                    <p className="text-xs text-slate-500">2026-05-02 10:15:05 UTC</p>
                  </div>
                </div>
             </div>
           </Card>
        </div>

        {/* Action Bar */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between gap-4">
          <input type="text" placeholder="Required: Enter justification for action..." className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">Contact Vendor</button>
            <button className="px-4 py-2 bg-orange-100 hover:bg-orange-200 text-orange-700 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">Escalate</button>
            <button className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">Reject</button>
            <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold transition-colors shadow-md shadow-purple-500/20">Approve / Override</button>
          </div>
        </div>

      </div>
    </div>
  </div>
);

const VendorIntelligence = () => (
  <div className="space-y-6 animate-in fade-in duration-500 h-full flex flex-col">
    <div className="flex justify-between items-center mb-2">
      <h2 className="text-2xl font-bold text-slate-800">Vendor Intelligence</h2>
      <button className="px-4 py-2 bg-white border border-slate-200 shadow-sm text-slate-700 rounded-lg text-sm font-semibold hover:bg-slate-50 transition-colors" title="Trigger API calls to sync latest GST and Watchlist data">Refresh External Data</button>
    </div>
    
    <div className="grid grid-cols-3 gap-6 flex-none">
      <div className="col-span-2 flex flex-col h-[280px]">
        <Card title="Vendor Network Graph (Collusion Detection)" className="flex-1 flex flex-col">
          <div className="flex-1 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-center relative overflow-hidden">
            <div className="absolute top-1/2 left-1/2 w-32 h-1 bg-purple-500/50 -rotate-45 origin-left"></div>
            <div className="absolute top-1/2 left-1/2 w-48 h-1 bg-red-500/50 rotate-12 origin-left"></div>
            <div className="absolute top-1/2 left-1/2 -ml-6 -mt-6 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-xs font-bold text-slate-800 border-4 border-purple-500 z-10">V1</div>
            <div className="absolute top-[30%] left-[70%] -ml-6 -mt-6 w-12 h-12 bg-slate-800 rounded-full shadow-lg flex items-center justify-center text-xs font-bold text-white border-2 border-red-500 z-10">Dir A</div>
            <div className="absolute top-[60%] left-[80%] -ml-6 -mt-6 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-xs font-bold text-slate-800 border-4 border-orange-500 z-10">V2</div>
            <div className="absolute bottom-4 left-4 bg-slate-800/80 backdrop-blur text-white text-xs p-3 rounded-lg max-w-xs">
              <span className="text-red-400 font-bold">Alert:</span> Shared director "Dir A" detected between Vendor 1 and Vendor 2 despite bidding on the same RFP.
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-6 h-[280px]">
        <Card title="External Risk Metrics" className="flex-1 flex flex-col justify-center">
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <span className="text-sm font-medium">Valid / Active GST</span>
              <span className="text-sm text-green-600 font-bold">14,203</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-sm font-medium">Suspended / Fake GST</span>
              <span className="text-sm text-red-600 font-bold">42</span>
            </div>
            <div className="bg-orange-50 p-3 rounded border border-orange-100">
              <p className="text-xs font-medium text-orange-800">Multiple vendors sharing IP</p>
              <p className="text-xl font-bold text-orange-600">8 clusters</p>
            </div>
          </div>
        </Card>
      </div>
    </div>

    <Card title="Vendor Master List (Sorted by Severity)" className="flex-1 flex flex-col min-h-[300px] overflow-hidden">
      <div className="flex-1 overflow-auto -mx-6 -mb-6 px-6 pb-6">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-500 uppercase bg-slate-50 sticky top-0 border-b border-slate-200">
            <tr>
              <th className="py-3 px-4 font-semibold">Vendor Name</th>
              <th className="py-3 px-4 font-semibold">GSTIN Status</th>
              <th className="py-3 px-4 font-semibold">Shell Risk Score</th>
              <th className="py-3 px-4 font-semibold">Collusion Flags</th>
              <th className="py-3 px-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {[
              { name: "TechCorp Logistics", gst: "Suspended", score: 98, flags: "Shared IP, Director Collision", class: "bg-red-50/50" },
              { name: "Global Supplies Inc", gst: "Active", score: 85, flags: "Zero Footprint", class: "bg-orange-50/50" },
              { name: "Apex Solutions", gst: "Active", score: 60, flags: "None", class: "" },
              { name: "Prime Manufacturing", gst: "Active", score: 12, flags: "None", class: "" },
              { name: "Blue Sky Trading", gst: "Active", score: 5, flags: "None", class: "" },
              { name: "Quantum IT", gst: "Suspended", score: 95, flags: "Blacklisted Address", class: "bg-red-50/50" }
            ].map((v, i) => (
              <tr key={i} className={`border-b border-slate-100 hover:bg-slate-100 transition-colors ${v.class}`}>
                <td className="py-3 px-4 font-medium text-slate-800">{v.name}</td>
                <td className={`py-3 px-4 font-semibold ${v.gst === 'Suspended' ? 'text-red-600' : 'text-green-600'}`}>{v.gst}</td>
                <td className="py-3 px-4">
                   <div className="flex items-center gap-2">
                     <div className="w-full bg-slate-200 rounded-full h-1.5 max-w-[60px]">
                       <div className={`h-1.5 rounded-full ${v.score > 80 ? 'bg-red-500' : v.score > 50 ? 'bg-orange-500' : 'bg-green-500'}`} style={{width: `${v.score}%`}}></div>
                     </div>
                     <span className="font-bold text-slate-700">{v.score}</span>
                   </div>
                </td>
                <td className="py-3 px-4 text-slate-600">{v.flags}</td>
                <td className="py-3 px-4 text-right">
                  <button className="text-purple-600 hover:text-purple-800 font-semibold text-xs">View Profile</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  </div>
);

const DataExplorer = () => (
  <div className="space-y-6 animate-in fade-in duration-500 h-full flex flex-col">
    <div className="flex justify-between items-center mb-2">
      <h2 className="text-2xl font-bold text-slate-800">Data Explorer</h2>
      <div className="flex gap-2">
        <select className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-sm font-semibold">
           <option>Raw Invoices Table</option>
           <option>PO / GRN Records</option>
           <option>Raw Audit Results</option>
           <option>Vendor Master List</option>
           <option>Agent Execution Logs</option>
        </select>
        <button className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-semibold hover:bg-purple-700 transition-colors shadow-sm flex items-center gap-2">
           <Download size={16} /> Export View
        </button>
      </div>
    </div>
    
    <Card className="flex-1 flex flex-col overflow-hidden p-0 border-slate-200 shadow-sm">
      <div className="p-4 border-b border-slate-200 bg-slate-50 flex gap-4">
        <div className="flex-1 relative">
           <input type="text" placeholder="Search entire dataset (e.g. INV-9921, TechCorp)..." className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
           <FileSearch className="absolute left-3 top-2.5 text-slate-400" size={16} />
        </div>
        <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-colors flex items-center gap-2 shadow-sm">
          <Settings size={16} /> Advanced Filters
        </button>
      </div>
      <div className="flex-1 overflow-auto bg-white">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-slate-500 uppercase bg-slate-100 sticky top-0 border-b border-slate-200 shadow-sm z-10">
            <tr>
              <th className="py-3 px-6 font-semibold">ID</th>
              <th className="py-3 px-6 font-semibold">Date</th>
              <th className="py-3 px-6 font-semibold">Vendor</th>
              <th className="py-3 px-6 font-semibold">Amount</th>
              <th className="py-3 px-6 font-semibold">AI Risk Score</th>
              <th className="py-3 px-6 font-semibold">Raw JSON Output</th>
              <th className="py-3 px-6 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {Array.from({length: 15}).map((_, i) => {
              const score = Math.floor(Math.random() * 100);
              return (
              <tr key={i} className="border-b border-slate-100 hover:bg-purple-50/50 transition-colors">
                <td className="py-3 px-6 font-mono text-slate-600">INV-990{i}</td>
                <td className="py-3 px-6 text-slate-600">2026-05-0{Math.max(1, i%5 + 1)}</td>
                <td className="py-3 px-6 font-medium text-slate-800">Vendor {String.fromCharCode(65+i)}</td>
                <td className="py-3 px-6 text-slate-600">${(Math.random() * 50000).toFixed(2)}</td>
                <td className="py-3 px-6">
                  <span className={`px-2 py-1 rounded font-bold text-xs ${score > 80 ? 'bg-red-100 text-red-700' : score > 50 ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>{score}</span>
                </td>
                <td className="py-3 px-6">
                  <span className="px-2 py-1 bg-slate-100 border border-slate-200 text-slate-600 text-[10px] rounded font-mono cursor-pointer hover:bg-slate-200">{"{ flags: [...] }"}</span>
                </td>
                <td className="py-3 px-6 text-right">
                  <button className="text-purple-600 hover:text-purple-800 font-semibold text-xs">View Full Record</button>
                </td>
              </tr>
            )})}
          </tbody>
        </table>
      </div>
    </Card>
  </div>
);

const PlaceholderPage = ({ title }) => (
  <div className="flex items-center justify-center h-full">
    <div className="text-center text-slate-400">
      <Settings className="w-16 h-16 mx-auto mb-4 opacity-50" />
      <h2 className="text-2xl font-bold">{title}</h2>
      <p className="mt-2">Module under construction.</p>
    </div>
  </div>
);

const AuditReports = () => (
  <div className="space-y-6 animate-in fade-in duration-500 h-full flex flex-col">
    <div className="flex justify-between items-center mb-4">
      <h2 className="text-2xl font-bold text-slate-800">Automated Audit Packs</h2>
      <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold transition-colors flex items-center gap-2 shadow-md shadow-purple-500/20">
        Generate Custom Report
      </button>
    </div>

    <div className="grid grid-cols-3 gap-6 flex-1 min-h-0 overflow-auto pb-6">
      {[
        { title: "Monthly Exception Summary", date: "May 2026", desc: "Aggregated view of all flagged items, overrides, and final statuses." },
        { title: "Vendor Risk Profile Export", date: "May 2026", desc: "Detailed breakdown of external risk metrics, GST statuses, and shell heuristics." },
        { title: "ISA 230 Traceability Log", date: "Q2 2026", desc: "Immutable chain of evidence for all transactions processed by the AI agents." },
        { title: "Proactive Tax Insights", date: "YTD 2026", desc: "Consolidated report on missed ITCs and structural procurement recommendations." },
        { title: "Collusion Network Export", date: "Last 30 Days", desc: "Graph data and identified clusters for offline regulatory review." }
      ].map((report, i) => (
        <Card key={i} className="flex flex-col hover:border-purple-200 transition-colors cursor-pointer group">
          <div className="flex-1">
            <h3 className="text-lg font-bold text-slate-800 group-hover:text-purple-700 transition-colors">{report.title}</h3>
            <p className="text-xs text-purple-600 font-bold tracking-wide uppercase mb-3 mt-1">{report.date}</p>
            <p className="text-sm text-slate-600 leading-relaxed">{report.desc}</p>
          </div>
          <div className="mt-6 flex gap-3 pt-4 border-t border-slate-100">
            <button className="flex-1 flex justify-center items-center gap-2 py-2 bg-slate-50 hover:bg-slate-100 hover:text-purple-700 text-slate-700 rounded text-sm font-semibold border border-slate-200 transition-colors">
              <Download size={16} /> PDF
            </button>
            <button className="flex-1 flex justify-center items-center gap-2 py-2 bg-slate-50 hover:bg-slate-100 hover:text-purple-700 text-slate-700 rounded text-sm font-semibold border border-slate-200 transition-colors">
              <Download size={16} /> CSV
            </button>
          </div>
        </Card>
      ))}
    </div>
  </div>
);

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/dashboard" element={<AnalyticsDashboard />} />
          <Route path="/explorer" element={<DataExplorer />} />
          <Route path="/ingestion" element={<PlaceholderPage title="Data Ingestion & Policy" />} />
          <Route path="/workspace" element={<AuditWorkspace />} />
          <Route path="/vendor" element={<VendorIntelligence />} />
          <Route path="/reports" element={<AuditReports />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
