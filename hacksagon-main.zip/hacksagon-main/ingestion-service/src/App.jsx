import { useState, useEffect, useRef, useCallback } from 'react';
import { marked } from 'marked';

// Configure marked for safe rendering
marked.setOptions({ breaks: true, gfm: true });

const TABLES = [
  { key: 'invoices',        icon: '🧾', name: 'Invoices',        cols: 8 },
  { key: 'purchase_orders', icon: '📋', name: 'Purchase Orders', cols: 5 },
  { key: 'goods_receipts',  icon: '📦', name: 'Goods Receipts',  cols: 4 },
  { key: 'approval_logs',   icon: '✅', name: 'Approval Logs',   cols: 7 },
  { key: 'vendor_master',   icon: '🏢', name: 'Vendor Master',   cols: 6 },
];

// ── Policy Editor Component ───────────────────────────────────
function PolicyEditor() {
  const [policies, setPolicies] = useState([]);
  const [selected, setSelected] = useState(null); // full policy object being edited
  const [draft, setDraft] = useState('');          // markdown text in editor
  const [draftName, setDraftName] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState(null);    // { type: 'ok'|'err', text }
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [previewMode, setPreviewMode] = useState('split'); // 'split' | 'edit' | 'preview'

  const fetchPolicies = useCallback(() => {
    setLoading(true);
    fetch('/api/policies')
      .then(r => r.json())
      .then(data => { setPolicies(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => { fetchPolicies(); }, [fetchPolicies]);

  const openPolicy = async (p) => {
    const res = await fetch(`/api/policies/${p.policy_id}`);
    const full = await res.json();
    setSelected(full);
    setDraft(full.markdown_content || '');
    setDraftName(full.policy_name || '');
    setSaveMsg(null);
  };

  const savePolicy = async () => {
    if (!selected) return;
    setSaving(true);
    setSaveMsg(null);
    try {
      const res = await fetch(`/api/policies/${selected.policy_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markdown_content: draft, policy_name: draftName }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setSaveMsg({ type: 'ok', text: `Saved — v${parseFloat(data.version_number).toFixed(1)}` });
      setSelected(data);
      fetchPolicies();
    } catch (err) {
      setSaveMsg({ type: 'err', text: err.message });
    }
    setSaving(false);
  };

  const createPolicy = async () => {
    if (!newName.trim()) return;
    try {
      const res = await fetch('/api/policies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ policy_name: newName.trim(), markdown_content: `# ${newName.trim()}\n\nEnter policy content here.` }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setCreating(false);
      setNewName('');
      fetchPolicies();
      openPolicy(data);
    } catch (err) {
      alert(err.message);
    }
  };

  const deletePolicy = async (id) => {
    try {
      await fetch(`/api/policies/${id}`, { method: 'DELETE' });
      if (selected?.policy_id === id) { setSelected(null); setDraft(''); }
      setConfirmDelete(null);
      fetchPolicies();
    } catch (err) {
      alert(err.message);
    }
  };

  const isDirty = selected && (draft !== (selected.markdown_content || '') || draftName !== selected.policy_name);

  return (
    <div className="policy-editor-layout">
      {/* Sidebar — policy list */}
      <aside className="policy-sidebar">
        <div className="policy-sidebar-header">
          <span className="policy-sidebar-title">📜 Policies</span>
          <button className="btn-new-policy" onClick={() => setCreating(true)} title="New policy">＋</button>
        </div>

        {creating && (
          <div className="new-policy-form">
            <input
              className="policy-name-input"
              placeholder="Policy name…"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && createPolicy()}
              autoFocus
            />
            <div className="new-policy-actions">
              <button className="btn-create-confirm" onClick={createPolicy}>Create</button>
              <button className="btn-create-cancel" onClick={() => { setCreating(false); setNewName(''); }}>Cancel</button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="policy-loading">Loading…</div>
        ) : policies.length === 0 ? (
          <div className="policy-empty-list">No policies yet.<br />Click ＋ to create one.</div>
        ) : (
          <ul className="policy-list">
            {policies.map(p => (
              <li key={p.policy_id}
                  className={`policy-list-item ${selected?.policy_id === p.policy_id ? 'active' : ''}`}
                  onClick={() => openPolicy(p)}>
                <div className="policy-item-main">
                  <span className="policy-item-name">{p.policy_name}</span>
                  <span className={`policy-item-status ${p.is_active ? 'active' : 'inactive'}`}>
                    {p.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="policy-item-meta">
                  v{parseFloat(p.version_number || 1).toFixed(1)} · {p.updated_by || 'Admin'}
                  {p.last_updated && <> · {new Date(p.last_updated).toLocaleDateString()}</>}
                </div>
                {confirmDelete === p.policy_id ? (
                  <div className="confirm-delete" onClick={e => e.stopPropagation()}>
                    <span>Delete?</span>
                    <button className="btn-del-yes" onClick={() => deletePolicy(p.policy_id)}>Yes</button>
                    <button className="btn-del-no" onClick={() => setConfirmDelete(null)}>No</button>
                  </div>
                ) : (
                  <button className="btn-delete-policy" onClick={e => { e.stopPropagation(); setConfirmDelete(p.policy_id); }} title="Delete">🗑</button>
                )}
              </li>
            ))}
          </ul>
        )}
      </aside>

      {/* Editor pane */}
      {selected ? (
        <div className="policy-edit-pane">
          {/* Editor toolbar */}
          <div className="editor-toolbar">
            <input
              className="editor-name-input"
              value={draftName}
              onChange={e => setDraftName(e.target.value)}
            />
            <div className="editor-toolbar-right">
              <div className="view-toggle">
                {['edit','split','preview'].map(m => (
                  <button key={m}
                    className={`view-toggle-btn ${previewMode === m ? 'active' : ''}`}
                    onClick={() => setPreviewMode(m)}>
                    {m === 'edit' ? '✏️ Edit' : m === 'split' ? '⚡ Split' : '👁 Preview'}
                  </button>
                ))}
              </div>
              {saveMsg && (
                <span className={`save-msg ${saveMsg.type}`}>{saveMsg.text}</span>
              )}
              <button
                className="btn-save"
                onClick={savePolicy}
                disabled={saving || !isDirty}>
                {saving ? '⏳ Saving…' : isDirty ? '💾 Save Changes' : '✓ Saved'}
              </button>
            </div>
          </div>

          {/* Policy meta bar */}
          <div className="policy-meta-bar">
            <span>Policy ID: <strong>#{selected.policy_id}</strong></span>
            <span>Version: <strong>v{parseFloat(selected.version_number || 1).toFixed(1)}</strong></span>
            <span>Last saved: <strong>{selected.last_updated ? new Date(selected.last_updated).toLocaleString() : 'Never'}</strong></span>
            <span>By: <strong>{selected.updated_by || 'Admin'}</strong></span>
            <label className="toggle-active">
              <input type="checkbox" checked={!!selected.is_active}
                onChange={async e => {
                  const res = await fetch(`/api/policies/${selected.policy_id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ is_active: e.target.checked }),
                  });
                  const data = await res.json();
                  if (!data.error) { setSelected(data); fetchPolicies(); }
                }} />
              Active
            </label>
          </div>

          {/* Split editor */}
          <div className={`editor-split editor-split--${previewMode}`}>
            {previewMode !== 'preview' && (
              <div className="editor-raw-pane">
                <div className="pane-label">Markdown</div>
                <textarea
                  className="md-textarea"
                  value={draft}
                  onChange={e => setDraft(e.target.value)}
                  spellCheck={false}
                  placeholder="Write policy in Markdown…"
                />
              </div>
            )}
            {previewMode !== 'edit' && (
              <div className="editor-preview-pane">
                <div className="pane-label">Preview</div>
                <div
                  className="md-preview"
                  dangerouslySetInnerHTML={{ __html: marked.parse(draft || '_No content_') }}
                />
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="policy-placeholder">
          <div className="policy-placeholder-icon">📄</div>
          <div className="policy-placeholder-text">Select a policy to edit</div>
          <div className="policy-placeholder-sub">Or click ＋ to create a new one</div>
        </div>
      )}
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState('ingestion'); // 'ingestion' | 'policies'
  const [selectedTable, setSelectedTable] = useState('invoices');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [schema, setSchema] = useState(null);
  const [activeJob, setActiveJob] = useState(null);
  const [jobHistory, setJobHistory] = useState([]);
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [pipelinePhase, setPipelinePhase] = useState('idle');
  const fileInput = useRef(null);
  const pollRef = useRef(null);

  useEffect(() => {
    fetch(`/api/schema/${selectedTable}`)
      .then(r => r.json()).then(setSchema).catch(() => {});
  }, [selectedTable]);

  useEffect(() => {
    fetch('/api/jobs').then(r => r.json()).then(setJobHistory).catch(() => {});
  }, []);

  useEffect(() => {
    if (!activeJob) return;
    pollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`/api/jobs/${activeJob.id}`);
        const job = await res.json();
        setActiveJob(job);
        if (job.status === 'producing') setPipelinePhase('producing');
        else if (job.status === 'consuming') setPipelinePhase('consuming');
        else if (job.status === 'complete' || job.status === 'failed') {
          setPipelinePhase('complete');
          clearInterval(pollRef.current);
          fetch('/api/jobs').then(r => r.json()).then(setJobHistory).catch(() => {});
          setTimeout(() => { setActiveJob(null); setPipelinePhase('idle'); }, 4000);
        }
      } catch (_) {}
    }, 400);
    return () => clearInterval(pollRef.current);
  }, [activeJob?.id]);

  const handleFile = useCallback(async (f) => {
    if (!f) return;
    setFile(f);
    setPipelinePhase('parsing');
    const form = new FormData();
    form.append('file', f);
    try {
      const res = await fetch('/api/preview', { method: 'POST', body: form });
      const data = await res.json();
      setPreview(data);
    } catch (err) { console.error('Preview error:', err); }
    setPipelinePhase('idle');
  }, []);

  const onDrop = useCallback((e) => {
    e.preventDefault(); setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const removeFile = () => { setFile(null); setPreview(null); };

  const handleUpload = async () => {
    if (!file || uploading) return;
    setUploading(true); setPipelinePhase('producing');
    const form = new FormData();
    form.append('file', file); form.append('targetTable', selectedTable);
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await res.json();
      if (data.error) { alert(`Upload error: ${data.error}`); setPipelinePhase('idle'); }
      else {
        setActiveJob({ id: data.jobId, ...data, status: 'producing', processedRows: 0, insertedRows: 0, skippedRows: 0, errorRows: 0 });
        setFile(null); setPreview(null);
      }
    } catch (err) { alert(`Upload failed: ${err.message}`); setPipelinePhase('idle'); }
    setUploading(false);
  };

  const getColumnClass = (col) => {
    if (!schema) return '';
    return schema.columns.includes(col) ? 'col-match' : 'col-extra';
  };

  const getMissingCols = () => {
    if (!schema || !preview) return [];
    return schema.columns.filter(c => !preview.columns.includes(c));
  };

  const nodeClass = (phase, nodePhases) => {
    if (pipelinePhase === 'complete') return 'done';
    if (nodePhases.includes(pipelinePhase)) return 'active';
    return '';
  };

  const pct = activeJob ? Math.round((activeJob.processedRows / Math.max(activeJob.totalRows, 1)) * 100) : 0;

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <div className="header-icon">🔄</div>
          <div>
            <h1>AuditIQ — Data Control Center</h1>
            <p>Ingest financial data and manage company policies</p>
          </div>
        </div>
        <div className="header-badge"><span className="dot" /> Kafka Connected</div>
      </header>

      {/* Tab bar */}
      <div className="tab-bar">
        <button
          id="tab-ingestion"
          className={`tab-btn ${activeTab === 'ingestion' ? 'active' : ''}`}
          onClick={() => setActiveTab('ingestion')}>
          ⚡ Data Ingestion
        </button>
        <button
          id="tab-policies"
          className={`tab-btn ${activeTab === 'policies' ? 'active' : ''}`}
          onClick={() => setActiveTab('policies')}>
          📜 Policy Editor
        </button>
      </div>

      {/* ── Ingestion Tab ─────────────────────────────────── */}
      {activeTab === 'ingestion' && (
        <>
          {/* Pipeline Visualization */}
          <div className="card animate-in">
            <div className="card-title"><span className="icon">⚡</span> Live Pipeline Status</div>
            <div className="pipeline">
              <div className={`pipeline-node ${nodeClass(pipelinePhase, ['parsing','producing','consuming'])}`}>
                <div className="node-icon-wrap">📁</div>
                <div className="node-label">File Upload</div>
                <div className="node-sub">.xlsx / .csv</div>
              </div>
              <div className={`pipeline-connector ${nodeClass(pipelinePhase, ['parsing','producing','consuming'])}`} />
              <div className={`pipeline-node ${nodeClass(pipelinePhase, ['parsing','producing','consuming'])}`}>
                <div className="node-icon-wrap">⚙️</div>
                <div className="node-label">SheetJS Parser</div>
                <div className="node-sub">Column Mapping</div>
              </div>
              <div className={`pipeline-connector ${nodeClass(pipelinePhase, ['producing','consuming'])}`} />
              <div className={`pipeline-node ${nodeClass(pipelinePhase, ['producing','consuming'])}`}>
                <div className="node-icon-wrap">📡</div>
                <div className="node-label">Apache Kafka</div>
                <div className="node-sub">:9092</div>
              </div>
              <div className={`pipeline-connector ${nodeClass(pipelinePhase, ['consuming'])}`} />
              <div className={`pipeline-node ${nodeClass(pipelinePhase, ['consuming'])}`}>
                <div className="node-icon-wrap">🗄️</div>
                <div className="node-label">Neon PostgreSQL</div>
                <div className="node-sub">neondb</div>
              </div>
            </div>
          </div>

          {/* Active Job */}
          {activeJob && (
            <div className="card animate-in">
              <div className="card-title"><span className="icon">📊</span> Processing — {activeJob.fileName || 'Upload'}</div>
              <div className="progress-section">
                <div className="progress-stats">
                  <div className="stat-card cyan"><div className="stat-value">{activeJob.totalRows}</div><div className="stat-label">Total Rows</div></div>
                  <div className="stat-card emerald"><div className="stat-value">{activeJob.insertedRows}</div><div className="stat-label">Inserted</div></div>
                  <div className="stat-card amber"><div className="stat-value">{activeJob.skippedRows}</div><div className="stat-label">Skipped (dup)</div></div>
                  <div className="stat-card red"><div className="stat-value">{activeJob.errorRows}</div><div className="stat-label">Errors</div></div>
                </div>
                <div className="progress-bar-wrap">
                  <div className={`progress-bar-fill ${activeJob.status === 'complete' ? 'complete' : ''}`} style={{ width: `${pct}%` }} />
                </div>
                <div className="progress-info">
                  <span>{activeJob.processedRows} / {activeJob.totalRows} records via Kafka</span>
                  <span className="pct">{pct}%</span>
                </div>
                {activeJob.targetTable === 'invoices' && activeJob.status === 'complete' && (
                  <div className={`audit-trigger-status ${activeJob.auditStats ? 'complete' : ''}`}>
                    {!activeJob.auditTriggered && '⚠️ No new invoices — audit not triggered (all skipped)'}
                    {activeJob.auditTriggered && !activeJob.auditStats && (
                      <><span className="spin">⚙️</span> Agent audits running for {activeJob.auditInvoiceCount} invoices...</>
                    )}
                    {activeJob.auditStats && (
                      <>✓ Audit complete — {activeJob.auditStats.successCount} done, {activeJob.auditStats.hitlCount} HITL, {activeJob.auditStats.errorCount} errors</>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Upload Section */}
          {!activeJob && (
            <div className="card animate-in">
              <div className="card-title"><span className="icon">📤</span> Upload Data Source</div>
              <div className="upload-grid">
                <div className="table-selector-group">
                  <label>Target Table</label>
                  {TABLES.map(t => (
                    <button key={t.key}
                      className={`table-btn ${selectedTable === t.key ? 'selected' : ''}`}
                      onClick={() => { setSelectedTable(t.key); removeFile(); }}>
                      <span className="emoji">{t.icon}</span>
                      {t.name}
                      <span className="cols">{t.cols} cols</span>
                    </button>
                  ))}
                </div>

                <div>
                  <div className={`drop-zone ${isDragging ? 'dragging' : ''} ${file ? 'has-file' : ''}`}
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={onDrop}
                    onClick={() => !file && fileInput.current?.click()}>
                    <input ref={fileInput} type="file" accept=".xlsx,.xls,.csv"
                      style={{ display: 'none' }}
                      onChange={(e) => handleFile(e.target.files[0])} />
                    {!file ? (
                      <>
                        <div className="drop-icon">📂</div>
                        <div className="drop-text">Drag &amp; drop your file here, or <strong>browse</strong></div>
                        <div className="drop-hint">Supports .xlsx, .xls, .csv — Max 50 MB</div>
                      </>
                    ) : (
                      <div className="file-info">
                        <span style={{ fontSize: 28 }}>📄</span>
                        <div>
                          <div className="name">{file.name}</div>
                          <div className="meta">{(file.size / 1024).toFixed(1)} KB · {preview ? `${preview.totalRows} rows · ${preview.columns.length} cols` : 'Parsing...'}</div>
                        </div>
                        <button className="remove-btn" onClick={(e) => { e.stopPropagation(); removeFile(); }}>✕</button>
                      </div>
                    )}
                  </div>

                  {preview && schema && (
                    <div className="preview-wrap animate-in">
                      <div className="preview-header">
                        <h4>Column Preview — Sheet: {preview.sheetName}</h4>
                        <span className="preview-badge">{preview.totalRows} rows</span>
                      </div>
                      <div className="column-legend">
                        <span><span className="legend-dot match" /> Matched</span>
                        <span><span className="legend-dot extra" /> Extra (ignored)</span>
                        {getMissingCols().length > 0 && <span><span className="legend-dot missing" /> Missing: {getMissingCols().join(', ')}</span>}
                      </div>
                      <table className="preview-table">
                        <thead><tr>{preview.columns.map(c => <th key={c} className={getColumnClass(c)}>{c}</th>)}</tr></thead>
                        <tbody>
                          {preview.preview.map((row, i) => (
                            <tr key={i}>{preview.columns.map(c => <td key={c} className={getColumnClass(c)}>{row[c] ?? ''}</td>)}</tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <button className="btn-upload" onClick={handleUpload} disabled={!file || uploading || !preview}>
                    {uploading ? '⏳ Sending to Kafka...' : '🚀 Stream Through Kafka Pipeline'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Job History */}
          <div className="card animate-in">
            <div className="card-title"><span className="icon">📋</span> Ingestion History</div>
            {jobHistory.length === 0 ? (
              <div className="empty-state">
                <div className="icon">📭</div>
                <p>No ingestion jobs yet. Upload a file to get started.</p>
              </div>
            ) : (
              <table className="history-table">
                <thead>
                  <tr>
                    <th>File</th><th>Table</th><th>Rows</th><th>Inserted</th>
                    <th>Skipped</th><th>Errors</th><th>Status</th><th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {jobHistory.map(j => (
                    <tr key={j.id}>
                      <td>{j.fileName}</td>
                      <td>{j.targetTable}</td>
                      <td className="mono">{j.totalRows}</td>
                      <td className="mono">{j.insertedRows}</td>
                      <td className="mono">{j.skippedRows}</td>
                      <td className="mono">{j.errorRows}</td>
                      <td>
                        <span className={`badge badge-${j.status}`}>
                          {j.status === 'producing' && <><span className="dot" /> Producing</>}
                          {j.status === 'consuming' && <><span className="dot" /> Consuming</>}
                          {j.status === 'complete' && '✓ Complete'}
                          {j.status === 'failed' && '✕ Failed'}
                        </span>
                      </td>
                      <td className="mono">{new Date(j.createdAt).toLocaleTimeString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      {/* ── Policy Editor Tab ─────────────────────────────── */}
      {activeTab === 'policies' && (
        <div className="card animate-in" style={{ padding: 0, overflow: 'hidden', minHeight: '70vh' }}>
          <PolicyEditor />
        </div>
      )}
    </div>
  );
}
