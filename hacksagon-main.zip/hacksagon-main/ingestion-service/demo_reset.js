/**
 * demo_reset.js
 * Wipes all demo rows (50000 series), then seeds fresh demo vendors, POs, GRNs,
 * and resets audit_results.
 */
import { pool } from './server/db.js';

async function reset() {
  console.log('🔄 Resetting demo data to 50000 series...\n');

  // ── 1. Wipe all previous 50000 series rows
  await pool.query(`DELETE FROM audit_results  WHERE invoice_id    LIKE 'INV50%'`);
  await pool.query(`DELETE FROM approval_logs  WHERE transaction_id LIKE 'INV50%'`);
  await pool.query(`DELETE FROM invoices        WHERE invoice_id    LIKE 'INV50%'`);
  await pool.query(`DELETE FROM goods_receipts  WHERE grn_id        LIKE 'GRN50%'`);
  await pool.query(`DELETE FROM purchase_orders WHERE po_id         LIKE 'PO50%'`);
  await pool.query(`DELETE FROM vendor_master   WHERE vendor_id     LIKE 'VEND50%'`);
  console.log('✅ Cleared old 50000 series rows');

  // ── 2. Seed demo vendors
  const vendors = [
    ['VEND5001', 'TechNova Solutions Ltd',   '27AABCT3518Q1ZV', '12 MG Road, Pune, MH 411001',      'LOW',    false],
    ['VEND5002', 'FastBridge Supplies Co',   '29AAFCB2395M1ZD', '8 Residency Rd, Bengaluru, KA',     'MEDIUM', false],
    ['VEND5003', 'ShadowTrade Enterprises',  '07AABCS9321N1ZK', '41 Nehru Place, New Delhi, DL',     'HIGH',   true],   // BLACKLISTED
    ['VEND5004', 'Reliable Parts Pvt Ltd',   '24AADCR4812P1ZJ', '5 Sardar Patel Rd, Ahmedabad, GJ', 'LOW',    false],
    ['VEND5005', 'PrimeEdge Contractors',    '33AAECP7823Q1ZN', '22 Anna Salai, Chennai, TN',        'MEDIUM', false],
  ];
  for (const [id, name, gstin, addr, risk, bl] of vendors) {
    await pool.query(
      `INSERT INTO vendor_master(vendor_id,vendor_name,official_gstin,registered_address,risk_rating,blacklist_status)
       VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(vendor_id) DO UPDATE
       SET vendor_name=$2, official_gstin=$3, registered_address=$4, risk_rating=$5, blacklist_status=$6`,
      [id, name, gstin, addr, risk, bl]
    );
  }
  console.log('✅ Seeded 5 demo vendors (VEND5001-5005)');

  // ── 3. Seed demo POs
  const pos = [
    ['PO50001', 'VEND5001', 50000,   '2026-04-01', 'Approved'],
    ['PO50002', 'VEND5002', 75000,   '2026-04-03', 'Approved'],
    ['PO50003', 'VEND5003', 120000,  '2026-04-05', 'Approved'],
    ['PO50004', 'VEND5004', 35000,   '2026-04-08', 'Approved'],
    ['PO50005', 'VEND5005', 500000,  '2026-04-10', 'Approved'],
  ];
  for (const [id, vid, amt, date, status] of pos) {
    await pool.query(
      `INSERT INTO purchase_orders(po_id,vendor_id,po_amount,po_date,status)
       VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING`,
      [id, vid, amt, date, status]
    );
  }
  console.log('✅ Seeded 5 demo POs');

  // ── 4. Seed demo GRNs
  const grns = [
    ['GRN50001', 'PO50001', '2026-04-10', 50000],
    ['GRN50002', 'PO50002', '2026-04-11', 72000],
    ['GRN50003', 'PO50003', '2026-04-12', 120000],
    ['GRN50004', 'PO50004', '2026-04-13', 35000],
    ['GRN50005', 'PO50005', '2026-04-14', 500000],
  ];
  for (const [id, po, date, amt] of grns) {
    await pool.query(
      `INSERT INTO goods_receipts(grn_id,po_id,receipt_date,received_amount)
       VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING`,
      [id, po, date, amt]
    );
  }
  console.log('✅ Seeded 5 demo GRNs');

  await pool.end();
}
reset().catch(e => { console.error(e); process.exit(1); });
