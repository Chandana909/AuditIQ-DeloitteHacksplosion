/**
 * setup_qstash.js
 * Automatically configures your QStash schedules (HITL check + Weekly Report)
 * using the current ngrok URL and adding the bypass header.
 */
import 'dotenv/config';

const QSTASH_TOKEN = process.env.QSTASH_TOKEN;
const NGROK_URL = process.argv[2]; 

if (!QSTASH_TOKEN) {
  console.error('❌ QSTASH_TOKEN missing in .env');
  process.exit(1);
}

if (!NGROK_URL || !NGROK_URL.startsWith('http')) {
  console.error('❌ Please provide a valid ngrok URL. Example: node setup_qstash.js https://xyz.ngrok-free.app');
  process.exit(1);
}

async function setup() {
  console.log(`🚀 Configuring QStash for: ${NGROK_URL}\n`);

  const schedules = [
    {
      name: 'auditiq-hitl-watchdog',
      url: `${NGROK_URL}/api/qstash/check-hitl`,
      cron: '*/30 * * * *', 
    },
    {
      name: 'auditiq-weekly-report',
      url: `${NGROK_URL}/api/qstash/weekly-report`,
      cron: '0 9 * * 1', 
    }
  ];

  for (const s of schedules) {
    console.log(`Setting up ${s.name}...`);
    
    // For Schedules, the destination URL goes in the PATH: /v2/schedules/{url}
    const response = await fetch(`https://qstash.upstash.io/v2/schedules/${s.url}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${QSTASH_TOKEN}`,
        'Content-Type': 'application/json',
        'Upstash-Cron': s.cron,
        'Upstash-Forward-ngrok-skip-browser-warning': 'true' 
      },
      // Body is empty for schedules unless you want to send a payload
      body: JSON.stringify({})
    });

    if (response.ok) {
      const data = await response.json();
      console.log(`✅ ${s.name} created! ID: ${data.scheduleId}`);
    } else {
      const error = await response.text();
      console.error(`❌ Failed to create ${s.name}:`, error);
    }
  }

  console.log('\n✨ QStash configuration complete!');
}

setup();
