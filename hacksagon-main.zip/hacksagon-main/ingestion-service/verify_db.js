import { pool } from './server/db.js';

async function verify() {
  console.log('=== POST-UPLOAD DATABASE CHECK ===\n');
  
  // 1. Row counts
  const tables = ['invoices','purchase_orders','goods_receipts','approval_logs','vendor_master','audit_results'];
  console.log('ROW COUNTS (baseline → current):');
  const baseline = { invoices: 51, purchase_orders: 50, goods_receipts: 50, approval_logs: 50, vendor_master: 30, audit_results: 50 };
  for (const t of tables) {
    const r = await pool.query(`SELECT COUNT(*) FROM ${t}`);
    const curr = parseInt(r.rows[0].count);
    const diff = curr - baseline[t];
    console.log(`  ${t}: ${baseline[t]} → ${curr} (${diff >= 0 ? '+' : ''}${diff})`);
  }
  
  // 2. Verify test rows exist
  console.log('\nTEST ROWS IN invoices:');
  const testRows = await pool.query(`SELECT invoice_id, vendor_id, invoice_amount FROM invoices WHERE invoice_id LIKE 'TEST-%' ORDER BY invoice_id`);
  testRows.rows.forEach(r => console.log(`  ${r.invoice_id} | ${r.vendor_id} | ₹${r.invoice_amount}`));
  
  // 3. Verify auto-created audit_results skeletons
  console.log('\nAUDIT SKELETONS FOR TEST ROWS:');
  const skeletons = await pool.query(`SELECT invoice_id, risk_rating FROM audit_results WHERE invoice_id LIKE 'TEST-%'`);
  skeletons.rows.forEach(r => console.log(`  ${r.invoice_id} → ${r.risk_rating}`));
  
  // 4. Verify existing data still intact (spot check)
  console.log('\nSPOT CHECK — EXISTING DATA INTACT:');
  const existingInv = await pool.query(`SELECT invoice_id FROM invoices WHERE invoice_id LIKE 'INV4%' LIMIT 3`);
  console.log(`  Sample existing invoices: ${existingInv.rows.map(r => r.invoice_id).join(', ')}`);
  const existingAudit = await pool.query(`SELECT invoice_id, risk_rating FROM audit_results WHERE invoice_id LIKE 'INV4%' AND risk_rating IS NOT NULL LIMIT 3`);
  console.log(`  Sample audit results: ${existingAudit.rows.map(r => `${r.invoice_id}→${r.risk_rating}`).join(', ')}`);
  
  await pool.end();
}
verify();
