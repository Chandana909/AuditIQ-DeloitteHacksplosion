import { pool } from './server/db.js';

async function migrate() {
  console.log('=== AuditIQ Phase 2 — Safe DB Migrations ===\n');

  const migrations = [
    // audit_results — HITL tracking
    {
      name: 'audit_results.hitl_created_at',
      sql: `ALTER TABLE audit_results ADD COLUMN IF NOT EXISTS hitl_created_at TIMESTAMP DEFAULT NULL`
    },
    {
      name: 'audit_results.hitl_resolved_at',
      sql: `ALTER TABLE audit_results ADD COLUMN IF NOT EXISTS hitl_resolved_at TIMESTAMP DEFAULT NULL`
    },
    // audit_results — numeric risk score (complements existing risk_rating text)
    {
      name: 'audit_results.risk_score',
      sql: `ALTER TABLE audit_results ADD COLUMN IF NOT EXISTS risk_score NUMERIC DEFAULT NULL`
    },
    // audit_results — workflow lifecycle status
    {
      name: "audit_results.workflow_status",
      sql: `ALTER TABLE audit_results ADD COLUMN IF NOT EXISTS workflow_status VARCHAR(20) DEFAULT 'pending'`
    },
    // invoices — track which ingestion job created the row
    {
      name: 'invoices.ingestion_job_id',
      sql: `ALTER TABLE invoices ADD COLUMN IF NOT EXISTS ingestion_job_id VARCHAR(100) DEFAULT NULL`
    },
    // hitl_escalated flag — prevents spamming repeat emails
    {
      name: 'audit_results.hitl_escalated',
      sql: `ALTER TABLE audit_results ADD COLUMN IF NOT EXISTS hitl_escalated BOOLEAN DEFAULT FALSE`
    }
  ];

  for (const m of migrations) {
    try {
      await pool.query(m.sql);
      console.log(`  ✅ ${m.name}`);
    } catch (err) {
      console.error(`  ❌ ${m.name}: ${err.message}`);
    }
  }

  // Verify final schema
  console.log('\n=== audit_results columns after migration ===');
  const result = await pool.query(`
    SELECT column_name, data_type, column_default, is_nullable
    FROM information_schema.columns
    WHERE table_name = 'audit_results'
    ORDER BY ordinal_position
  `);
  result.rows.forEach(r => {
    console.log(`  ${r.column_name.padEnd(25)} ${r.data_type.padEnd(20)} nullable=${r.is_nullable} default=${r.column_default || 'none'}`);
  });

  console.log('\n=== invoices — new columns ===');
  const inv = await pool.query(`
    SELECT column_name, data_type, is_nullable
    FROM information_schema.columns
    WHERE table_name = 'invoices' AND column_name = 'ingestion_job_id'
  `);
  inv.rows.forEach(r => console.log(`  ${r.column_name} | ${r.data_type} | nullable=${r.is_nullable}`));

  await pool.end();
  console.log('\n✅ All migrations complete. Existing data untouched.');
}

migrate().catch(err => { console.error('Migration failed:', err); process.exit(1); });
