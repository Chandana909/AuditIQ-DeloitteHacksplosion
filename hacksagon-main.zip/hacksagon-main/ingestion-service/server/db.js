import { Pool } from 'pg';

const connectionString = "postgresql://neondb_owner:npg_NafhUtWPF51V@ep-bitter-credit-a1ffz9vw.ap-southeast-1.aws.neon.tech/neondb?sslmode=require";

export const pool = new Pool({ connectionString, max: 10 });

export const TABLE_SCHEMAS = {
  invoices: {
    columns: ['invoice_id', 'date', 'vendor_id', 'invoice_number', 'po_id', 'grn_id', 'invoice_amount', 'gstin'],
    primaryKey: 'invoice_id',
    displayName: 'Invoices',
    icon: '🧾'
  },
  purchase_orders: {
    columns: ['po_id', 'vendor_id', 'po_date', 'po_amount', 'status'],
    primaryKey: 'po_id',
    displayName: 'Purchase Orders',
    icon: '📋'
  },
  goods_receipts: {
    columns: ['grn_id', 'po_id', 'receipt_date', 'received_amount'],
    primaryKey: 'grn_id',
    displayName: 'Goods Receipts',
    icon: '📦'
  },
  approval_logs: {
    columns: ['log_id', 'transaction_id', 'approver_name', 'approver_role', 'timestamp', 'action_taken', 'amount_limit'],
    primaryKey: 'log_id',
    displayName: 'Approval Logs',
    icon: '✅'
  },
  vendor_master: {
    columns: ['vendor_id', 'vendor_name', 'official_gstin', 'registered_address', 'risk_rating', 'blacklist_status'],
    primaryKey: 'vendor_id',
    displayName: 'Vendor Master',
    icon: '🏢'
  },
  company_policies: {
    columns: ['policy_id', 'policy_name', 'content', 'is_active', 'version_number'],
    primaryKey: 'policy_id',
    displayName: 'Company Policies',
    icon: '📜'
  }
};

export async function insertRow(table, row) {
  const schema = TABLE_SCHEMAS[table];
  if (!schema) throw new Error(`Unknown table: ${table}`);

  const cols = schema.columns.filter(c => row[c] !== undefined && row[c] !== '');
  if (cols.length === 0) return { inserted: 0, skipped: 1 };

  const vals = cols.map(c => row[c]);
  const placeholders = cols.map((_, i) => `$${i + 1}`).join(', ');
  const query = `INSERT INTO ${table} (${cols.join(', ')}) VALUES (${placeholders}) ON CONFLICT (${schema.primaryKey}) DO NOTHING`;

  const result = await pool.query(query, vals);
  return { inserted: result.rowCount, skipped: result.rowCount === 0 ? 1 : 0 };
}

export async function createAuditSkeleton(invoiceId) {
  try {
    await pool.query(
      `INSERT INTO audit_results (invoice_id, risk_rating, flags_detected) VALUES ($1, 'Pending', '[]'::jsonb) ON CONFLICT (invoice_id) DO NOTHING`,
      [invoiceId]
    );
  } catch (_) { /* best-effort */ }
}
