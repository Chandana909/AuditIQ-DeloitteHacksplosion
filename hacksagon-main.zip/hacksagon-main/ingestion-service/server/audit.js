/**
 * audit.js — Post-ingestion agentic trigger module
 * ESM port of mass_audit.js logic, consumed by the ingestion backend.
 * mass_audit.js (CommonJS) is kept unchanged for manual runs.
 */

const FLOWISE_AUDIT_URL = 'https://agentbuilder3.ingenw-innovation-nonprod.deloitte.com/api/v1/prediction/8570af9e-7d76-408a-b755-6821649759e9';
const FLOWISE_MAIL_URL  = 'https://agentbuilder3.ingenw-innovation-nonprod.deloitte.com/api/v1/prediction/7d82d3ee-ddfd-46ee-9211-b1228072f3c9';
const CONCURRENCY = 5; 

export { FLOWISE_MAIL_URL };

// ── Response Parser ─────────────────────────────────────────
export function parseAgentResponse(rawData) {
  const result = {
    riskRating: 'Pending',
    riskScore: null,
    flagsDetected: [],
    policyVersion: null,
    explanation: null,
    recommendedAction: null,
    citation: null,
    chatId: rawData.chatId || rawData.sessionId || null,
    isHITL: false,
  };

  if (!rawData.text) { result.isHITL = true; return result; }

  if (rawData.text.includes('"type": "HITL_REQUIRED"')) {
    result.isHITL = true;
    try {
      const parsedText = JSON.parse(rawData.text);
      let unwrappedFlags = [];
      if (Array.isArray(parsedText.verifiedFlags)) unwrappedFlags = parsedText.verifiedFlags;
      else if (parsedText.verifiedFlags && Array.isArray(parsedText.verifiedFlags.verifiedFlags))
        unwrappedFlags = parsedText.verifiedFlags.verifiedFlags;
      parsedText.verifiedFlags = unwrappedFlags;
      result.explanation = JSON.stringify(parsedText);
      result.riskRating = parsedText.riskResult?.riskLevel || 'Pending';
      result.riskScore = parsedText.riskResult?.riskScore ?? null;
      result.recommendedAction = 'Pending';
      return result;
    } catch (_) {}
    return result;
  }

  try {
    const structured = JSON.parse(rawData.text);
    result.riskRating = structured.risk_rating || 'UNKNOWN';
    result.riskScore = structured.risk_score ?? null;
    result.flagsDetected = structured.flags_detected || [];
    result.policyVersion = structured.policy_version_applied || null;
    result.explanation = structured.explanation || 'No explanation provided.';
    result.recommendedAction = structured.recommended_action || null;
    result.citation = structured.citation || null;
  } catch (_) {
    result.explanation = 'Error: Invalid JSON response from Agent.';
    result.riskRating = 'ERROR';
  }
  return result;
}

// ── ABC classification ───────────────────────────────────────
function computeTransactionClass(invoiceAmount) {
  const amt = parseFloat(invoiceAmount) || 0;
  if (amt > 500000) return 'A';
  if (amt > 100000) return 'B';
  return 'C';
}

// ── Class A Fraud Alert ──────────────────────────────────────
async function checkClassAFraudAlert(pool) {
  const CLASS_A_FRAUD_THRESHOLD_PCT = 5; 

  const res = await pool.query(`
    SELECT
      COUNT(*) FILTER (WHERE transaction_class = 'A')                                          AS total_class_a,
      COUNT(*) FILTER (WHERE transaction_class = 'A' AND risk_rating IN ('HIGH','CRITICAL'))   AS fraud_class_a,
      ROUND(
        100.0 * COUNT(*) FILTER (WHERE transaction_class = 'A' AND risk_rating IN ('HIGH','CRITICAL'))
              / NULLIF(COUNT(*) FILTER (WHERE transaction_class = 'A'), 0),
        1
      )                                                                                         AS fraud_pct_class_a
    FROM audit_results
    WHERE risk_rating IS NOT NULL AND risk_rating != 'Pending';
  `);

  if (res.rows.length > 0) {
    const stats = res.rows[0];
    const pct = parseFloat(stats.fraud_pct_class_a) || 0;

    if (pct >= CLASS_A_FRAUD_THRESHOLD_PCT) {
      console.warn(`\n⚠️  ALERT: Class A fraud rate is ${pct}% — triggering MailAgent...`);
      try {
        await fetch(FLOWISE_MAIL_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: `ALERT: Class A fraud rate is ${pct}% (${stats.fraud_class_a} out of ${stats.total_class_a} Class A invoices). Please notify the audit team immediately.`
          })
        });
      } catch(err) {
        console.error('Failed to trigger MailAgent:', err.message);
      }
    }
  }
}

// ── Trigger audit for a batch of invoice IDs ────────────────
export async function triggerAuditBatch(invoiceIds, pool, jobId = null) {
  if (!invoiceIds || invoiceIds.length === 0) return;

  console.log(`\n🤖 Triggering agentic audit for ${invoiceIds.length} invoices...`);
  
  // Fetch amounts first for ABC classification
  const amtRes = await pool.query(`
    SELECT invoice_id, COALESCE(invoice_amount, 0) as amount 
    FROM invoices WHERE invoice_id = ANY($1)
  `, [invoiceIds]);
  const amtMap = new Map(amtRes.rows.map(r => [r.invoice_id, r.amount]));

  let successCount = 0, hitlCount = 0, errorCount = 0;

  for (let i = 0; i < invoiceIds.length; i += CONCURRENCY) {
    const batch = invoiceIds.slice(i, i + CONCURRENCY);
    const promises = batch.map(async (invoiceId) => {
      try {
        const txnClass = computeTransactionClass(amtMap.get(invoiceId) || 0);

        const response = await fetch(FLOWISE_AUDIT_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            question: invoiceId,
            overrideConfig: { modelName: 'qwen3.5-35b-hacksplosion' }
          })
        });
        if (!response.ok) throw new Error(`Flowise ${response.status}`);

        const rawData = await response.json();
        const parsed = parseAgentResponse(rawData);

        let workflowStatus = 'Flagged';
        if (parsed.isHITL) workflowStatus = 'Pending Review';
        else if (['LOW', 'MEDIUM'].includes(parsed.riskRating)) workflowStatus = 'Approved';

        await pool.query(`
          UPDATE audit_results
          SET risk_rating             = $1,
              risk_score              = $2,
              flags_detected          = $3::jsonb,
              flag_count              = jsonb_array_length($3::jsonb),
              policy_version_applied  = $4,
              session_id              = $5,
              explanation             = $6,
              recommended_action      = $7,
              citation                = $8,
              workflow_status         = $9,
              requires_hitl           = $10,
              transaction_class       = $11,
              updated_at              = NOW()
          WHERE invoice_id = $12
        `, [
          parsed.riskRating,
          parsed.riskScore,
          JSON.stringify(parsed.flagsDetected),
          parsed.policyVersion,
          parsed.chatId,
          parsed.explanation,
          parsed.recommendedAction,
          parsed.citation,
          workflowStatus,
          parsed.isHITL,
          txnClass,
          invoiceId
        ]);

        if (parsed.isHITL) {
          hitlCount++;
          console.log(`  [HITL]  ${invoiceId} → paused for human review`);
        } else {
          successCount++;
          console.log(`  [OK]    ${invoiceId} → ${parsed.riskRating} | flags: ${parsed.flagsDetected.length}`);
        }
      } catch (err) {
        errorCount++;
        console.error(`  [ERR]   ${invoiceId} → ${err.message}`);
      }
    });
    await Promise.all(promises);
  }

  await checkClassAFraudAlert(pool);
  console.log(`✅ Audit batch done: ${successCount} complete, ${hitlCount} HITL, ${errorCount} errors\n`);
  return { successCount, hitlCount, errorCount };
}
