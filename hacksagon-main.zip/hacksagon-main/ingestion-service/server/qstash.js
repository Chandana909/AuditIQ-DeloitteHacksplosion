/**
 * qstash.js — QStash webhook handlers
 * HITL 4-hour watchdog + weekly audit report scheduler
 */

import { pool } from './db.js';
import { FLOWISE_MAIL_URL } from './audit.js';

const MANAGER_EMAIL = 'rimdaas30@gmail.com';

// ── Call the Flowise mail agent ──────────────────────────────
async function sendViaMaiAgent(payload) {
  const res = await fetch(FLOWISE_MAIL_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question: JSON.stringify(payload) })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Mail agent responded ${res.status}: ${text.substring(0, 200)}`);
  }
  return await res.json();
}

// ── HITL Watchdog ────────────────────────────────────────────
// Called by QStash every 30 min; only emails if HITL has been
// unresolved for >= 4 hours AND email hasn't been sent yet.
export async function handleHITLCheck(req, res) {
  try {
    // Find HITL rows: unresolved for 4+ hours, not yet escalated
    const result = await pool.query(`
      SELECT
        ar.invoice_id,
        ar.risk_rating,
        ar.risk_score,
        ar.hitl_created_at,
        ar.session_id,
        ar.flags_detected,
        i.vendor_id,
        vm.vendor_name
      FROM audit_results ar
      LEFT JOIN invoices i ON i.invoice_id = ar.invoice_id
      LEFT JOIN vendor_master vm ON vm.vendor_id = i.vendor_id
      WHERE ar.workflow_status = 'hitl_pending'
        AND ar.hitl_resolved_at IS NULL
        AND ar.hitl_escalated IS NOT TRUE
        AND ar.hitl_created_at < NOW() - INTERVAL '4 hours'
    `);

    if (result.rows.length === 0) {
      console.log('⏱️  HITL check: no unresolved items past 4h threshold');
      return res.json({ checked: true, escalated: 0 });
    }

    console.log(`⚠️  HITL check: ${result.rows.length} unresolved items past 4h — escalating`);
    let escalated = 0;

    for (const row of result.rows) {
      try {
        const hoursWaiting = Math.round((Date.now() - new Date(row.hitl_created_at)) / 3600000);
        let flags = [];
        try { flags = typeof row.flags_detected === 'string' ? JSON.parse(row.flags_detected) : (row.flags_detected || []); } catch(_) {}
        const flagSummary = flags.map(f => f.flag || f.type || JSON.stringify(f)).join(', ') || 'Multiple flags detected';

        const mailPayload = {
          email_intent: 'internal_escalation',
          recipient: MANAGER_EMAIL,
          reference_id: row.invoice_id,
          risk_score: row.risk_rating || 'HIGH',
          entity_name: row.vendor_name || row.vendor_id || 'Unknown Vendor',
          issue: `Human-in-the-Loop review has been pending for ${hoursWaiting} hours without resolution.\n\nFlags: ${flagSummary}.\n\nSession ID: ${row.session_id || 'N/A'}. Please review on the AuditIQ dashboard.`,
          custom_instructions: 'This is an automated escalation. The invoice requires immediate human review on the AuditIQ dashboard.'
        };

        await sendViaMaiAgent(mailPayload);

        // Mark as escalated so we don't spam
        await pool.query(
          `UPDATE audit_results SET hitl_escalated = TRUE WHERE invoice_id = $1`,
          [row.invoice_id]
        );

        console.log(`  📧 Escalated ${row.invoice_id} to ${MANAGER_EMAIL} (${hoursWaiting}h pending)`);
        escalated++;
      } catch (err) {
        console.error(`  ❌ Failed to escalate ${row.invoice_id}: ${err.message}`);
      }
    }

    res.json({ checked: true, escalated, total: result.rows.length });
  } catch (err) {
    console.error('HITL check error:', err);
    res.status(500).json({ error: err.message });
  }
}

// ── Weekly Report ────────────────────────────────────────────
export async function handleWeeklyReport(req, res) {
  try {
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - 7);

    // Gather stats
    const [totals, riskBreakdown, topFlags, recentHITL, vendorStats] = await Promise.all([
      pool.query(`
        SELECT
          COUNT(*) AS total_audited,
          COUNT(*) FILTER (WHERE workflow_status = 'auto_approved') AS auto_approved,
          COUNT(*) FILTER (WHERE workflow_status = 'hitl_pending') AS hitl_pending,
          COUNT(*) FILTER (WHERE workflow_status = 'flagged') AS flagged,
          COUNT(*) FILTER (WHERE risk_rating = 'HIGH' OR risk_rating = 'CRITICAL') AS high_risk
        FROM audit_results
      `),
      pool.query(`
        SELECT risk_rating, COUNT(*) as cnt
        FROM audit_results
        WHERE risk_rating IS NOT NULL AND risk_rating != 'Pending'
        GROUP BY risk_rating ORDER BY cnt DESC
      `),
      pool.query(`
        SELECT jsonb_array_elements(flags_detected)->>'flag' as flag_name, COUNT(*) as cnt
        FROM audit_results
        WHERE flags_detected IS NOT NULL AND flags_detected != '[]'
        GROUP BY flag_name ORDER BY cnt DESC LIMIT 5
      `),
      pool.query(`
        SELECT ar.invoice_id, ar.risk_rating, ar.hitl_created_at, vm.vendor_name
        FROM audit_results ar
        LEFT JOIN invoices i ON i.invoice_id = ar.invoice_id
        LEFT JOIN vendor_master vm ON vm.vendor_id = i.vendor_id
        WHERE ar.workflow_status = 'hitl_pending'
        ORDER BY ar.hitl_created_at ASC LIMIT 5
      `),
      pool.query(`
        SELECT vm.vendor_name, vm.risk_rating AS vendor_risk, vm.blacklist_status,
               COUNT(ar.invoice_id) AS invoice_count,
               COUNT(ar.invoice_id) FILTER (WHERE ar.risk_rating IN ('HIGH','CRITICAL')) AS high_risk_invoices
        FROM vendor_master vm
        LEFT JOIN invoices i ON i.vendor_id = vm.vendor_id
        LEFT JOIN audit_results ar ON ar.invoice_id = i.invoice_id
        GROUP BY vm.vendor_id, vm.vendor_name, vm.risk_rating, vm.blacklist_status
        HAVING COUNT(ar.invoice_id) FILTER (WHERE ar.risk_rating IN ('HIGH','CRITICAL')) > 0
        ORDER BY high_risk_invoices DESC LIMIT 5
      `)
    ]);

    const t = totals.rows[0];
    const mailPayload = {
      email_intent: 'audit_summary',
      recipient: MANAGER_EMAIL,
      summary_data: {
        week: `${weekStart.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })} – ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}`,
        total_audited: parseInt(t.total_audited),
        auto_approved: parseInt(t.auto_approved),
        hitl_pending: parseInt(t.hitl_pending),
        flagged: parseInt(t.flagged),
        high_risk: parseInt(t.high_risk),
        risk_breakdown: riskBreakdown.rows.map(r => ({ rating: r.risk_rating, count: parseInt(r.cnt) })),
        top_flags: topFlags.rows.map(r => r.flag_name).filter(Boolean),
        pending_hitl_items: recentHITL.rows.map(r => ({ id: r.invoice_id, risk: r.risk_rating, vendor: r.vendor_name, waiting_since: r.hitl_created_at })),
        flagged_vendors: vendorStats.rows.map(r => ({ vendor: r.vendor_name, high_risk_invoices: parseInt(r.high_risk_invoices), blacklisted: r.blacklist_status }))
      },
      custom_instructions: 'Compose this as a professional weekly audit report. Use HTML tables for the data. Add a "Market Pulse" section by searching for the latest Indian GST compliance news, financial audit regulation updates, and any relevant corporate fraud headlines from the past week.'
    };

    const agentResult = await sendViaMaiAgent(mailPayload);
    console.log('📧 Weekly report dispatched to mail agent');
    res.json({ success: true, report: mailPayload.summary_data, agentResponse: agentResult?.text?.substring(0, 200) });
  } catch (err) {
    console.error('Weekly report error:', err);
    res.status(500).json({ error: err.message });
  }
}
