import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import * as XLSX from 'xlsx';
import { Receiver } from '@upstash/qstash';
import { TABLE_SCHEMAS, insertRow, createAuditSkeleton, pool } from './db.js';
import { initKafka, produceRows, startConsumer, createJob, getJob, getAllJobs, jobs } from './kafka.js';
import { triggerAuditBatch } from './audit.js';
import { handleHITLCheck, handleWeeklyReport } from './qstash.js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// QStash signature verifier (use your signing key from Upstash dashboard)
const QSTASH_CURRENT_SIGNING_KEY = process.env.QSTASH_CURRENT_SIGNING_KEY || '';
const QSTASH_NEXT_SIGNING_KEY    = process.env.QSTASH_NEXT_SIGNING_KEY    || '';

const qstashReceiver = QSTASH_CURRENT_SIGNING_KEY
  ? new Receiver({ currentSigningKey: QSTASH_CURRENT_SIGNING_KEY, nextSigningKey: QSTASH_NEXT_SIGNING_KEY })
  : null;

app.use(cors());

// Raw body needed for QStash signature verification on those routes
app.use('/api/qstash', express.raw({ type: '*/*' }));
app.use(express.json());

// ── QStash signature middleware ──────────────────────────────
async function verifyQStash(req, res, next) {
  // In dev without signing keys, skip verification
  if (!qstashReceiver) {
    console.warn('⚠️  QStash signature verification disabled (no signing keys set)');
    req.body = JSON.parse(req.body?.toString() || '{}');
    return next();
  }
  try {
    const signature = req.headers['upstash-signature'];
    const body = req.body.toString();
    
    const isValid = await qstashReceiver.verify({
      signature: signature,
      body: body,
    });

    if (!isValid) {
      console.error('❌ QStash Verification Failed: Invalid Signature');
      console.error('   Signature received:', signature?.substring(0, 20) + '...');
      return res.status(401).json({ error: 'Invalid QStash signature' });
    }
    
    console.log('✅ QStash Verification Success');
    req.body = JSON.parse(body || '{}');
    next();
  } catch (err) {
    console.error('❌ QStash Verification Error:', err.message);
    res.status(401).json({ error: 'QStash verification failed', detail: err.message });
  }
}

// ── File preview ─────────────────────────────────────────────
app.post('/api/preview', upload.single('file'), (req, res) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });
    const wb = XLSX.read(file.buffer, { type: 'buffer' });
    const sheet = wb.SheetNames[0];
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { raw: false });
    res.json({
      fileName: file.originalname,
      sheetName: sheet,
      totalRows: rows.length,
      columns: rows.length > 0 ? Object.keys(rows[0]) : [],
      preview: rows.slice(0, 5),
      sheets: wb.SheetNames
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Upload & ingest through Kafka ────────────────────────────
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const { targetTable } = req.body;
    const file = req.file;
    if (!file) return res.status(400).json({ error: 'No file uploaded' });
    if (!TABLE_SCHEMAS[targetTable]) return res.status(400).json({ error: `Invalid table: ${targetTable}` });

    const wb = XLSX.read(file.buffer, { type: 'buffer' });
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { raw: false });
    if (rows.length === 0) return res.status(400).json({ error: 'File contains no data rows' });

    const schema = TABLE_SCHEMAS[targetTable];
    const mapped = rows.map(row => {
      const obj = {};
      for (const col of schema.columns) {
        if (row[col] !== undefined && row[col] !== '') obj[col] = row[col];
      }
      return obj;
    }).filter(row => row[schema.primaryKey]);

    if (mapped.length === 0) {
      return res.status(400).json({
        error: `No rows contain the required primary key: ${schema.primaryKey}`,
        expected: schema.columns,
        found: rows.length > 0 ? Object.keys(rows[0]) : []
      });
    }

    const jobId = `job-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const job = createJob(jobId, file.originalname, targetTable, mapped.length);

    produceRows(jobId, targetTable, mapped).catch(err => {
      console.error(`Production error for ${jobId}:`, err.message);
      job.status = 'failed';
      job.errors.push(err.message);
    });

    res.json({ jobId, totalRows: mapped.length, targetTable });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── Job status ───────────────────────────────────────────────
app.get('/api/jobs/:id', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});
app.get('/api/jobs', (_req, res) => res.json(getAllJobs()));

// ── Schema info ──────────────────────────────────────────────
app.get('/api/schema/:table', (req, res) => {
  const schema = TABLE_SCHEMAS[req.params.table];
  if (!schema) return res.status(404).json({ error: 'Unknown table' });
  res.json(schema);
});

// ── Policy CRUD ───────────────────────────────────────────────
// GET all policies
app.get('/api/policies', async (_req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT policy_id, policy_name, version_number, is_active, last_updated, updated_by, created_at FROM company_policies ORDER BY policy_id DESC'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single policy (with full markdown_content)
app.get('/api/policies/:id', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM company_policies WHERE policy_id = $1',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Policy not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create new policy
app.post('/api/policies', async (req, res) => {
  try {
    const { policy_name, markdown_content, effective_date, updated_by } = req.body;
    if (!policy_name) return res.status(400).json({ error: 'policy_name is required' });
    const { rows } = await pool.query(
      `INSERT INTO company_policies (policy_name, markdown_content, version_number, effective_date, updated_by, is_active)
       VALUES ($1, $2, 1.0, $3, $4, true) RETURNING *`,
      [policy_name, markdown_content || '', effective_date || null, updated_by || 'Admin']
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update existing policy
app.put('/api/policies/:id', async (req, res) => {
  try {
    const { policy_name, markdown_content, is_active, updated_by } = req.body;
    const { rows } = await pool.query(
      `UPDATE company_policies
         SET markdown_content  = COALESCE($1, markdown_content),
             policy_name       = COALESCE($2, policy_name),
             is_active         = COALESCE($3, is_active),
             version_number    = version_number + 0.1,
             last_updated      = NOW(),
             updated_by        = COALESCE($4, updated_by)
       WHERE policy_id = $5
       RETURNING *`,
      [markdown_content ?? null, policy_name ?? null, is_active ?? null, updated_by || 'Admin', req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Policy not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE policy
app.delete('/api/policies/:id', async (req, res) => {
  try {
    const { rowCount } = await pool.query(
      'DELETE FROM company_policies WHERE policy_id = $1',
      [req.params.id]
    );
    if (!rowCount) return res.status(404).json({ error: 'Policy not found' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Health ───────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({ 
    status: 'ok', 
    kafka: 'connected', 
    timestamp: new Date().toISOString(),
    ngrok: process.env.NGROK_PUBLIC_URL || 'not_active'
  });
});

// ── QStash Endpoints ─────────────────────────────────────────
// POST /api/qstash/check-hitl — called by QStash every 30min, escalates 4h+ unresolved
app.post('/api/qstash/check-hitl', (req, res, next) => {
  console.log('🔔 Received QStash HITL check request');
  next();
}, verifyQStash, handleHITLCheck);

// POST /api/qstash/weekly-report — called by QStash CRON every Monday 9AM
app.post('/api/qstash/weekly-report', (req, res, next) => {
  console.log('📧 Received QStash Weekly Report request');
  next();
}, verifyQStash, handleWeeklyReport);

// Manual test triggers (no signature needed — useful for dev testing)
app.post('/api/test/check-hitl', handleHITLCheck);
app.post('/api/test/weekly-report', handleWeeklyReport);

// ── Boot ─────────────────────────────────────────────────────
async function start() {
  try {
    await initKafka();

    // Track inserted invoice IDs per job so we can trigger audits after completion
    const jobInsertedIds = new Map(); // jobId → Set<invoiceId>

    await startConsumer(async (data) => {
      const { jobId, targetTable, row } = data;
      const job = jobs.get(jobId);
      try {
        const result = await insertRow(targetTable, row);
        if (job) {
          job.processedRows++;
          job.insertedRows += result.inserted;
          job.skippedRows += result.skipped;

          // Track new invoice IDs for post-job audit trigger
          if (targetTable === 'invoices' && result.inserted > 0) {
            await createAuditSkeleton(row.invoice_id);
            if (!jobInsertedIds.has(jobId)) jobInsertedIds.set(jobId, []);
            jobInsertedIds.get(jobId).push(row.invoice_id);
          }

          if (job.processedRows >= job.totalRows) {
            job.status = 'complete';
            job.completedAt = new Date().toISOString();

            // ── Kick off agentic audit after invoices job completes ──
            if (targetTable === 'invoices') {
              const newIds = jobInsertedIds.get(jobId) || [];
              jobInsertedIds.delete(jobId);

              if (newIds.length > 0) {
                job.auditTriggered = true;
                job.auditInvoiceCount = newIds.length;
                console.log(`\n🔥 Job ${jobId} complete — triggering audit for ${newIds.length} new invoices`);

                // Fire-and-forget — doesn't block the consumer
                triggerAuditBatch(newIds, pool, jobId)
                  .then(stats => { job.auditStats = stats; })
                  .catch(err => { console.error('Audit trigger error:', err.message); });
              } else {
                job.auditTriggered = false;
                console.log(`ℹ️  Job ${jobId} complete — no new invoices (all skipped), audit not triggered`);
              }
            }
          }
        }
      } catch (err) {
        if (job) {
          job.processedRows++;
          job.errorRows++;
          job.errors.push(err.message);
          if (job.processedRows >= job.totalRows) {
            job.status = 'complete';
            job.completedAt = new Date().toISOString();
          }
        }
      }
    });

    app.listen(3001, () => {
      console.log('\n🚀 AuditIQ Ingestion Service → http://localhost:3001');
      console.log('📊 Frontend (Vite)          → http://localhost:5173');
      console.log('🔔 QStash HITL test         → POST http://localhost:3001/api/test/check-hitl');
      console.log('📧 QStash Report test       → POST http://localhost:3001/api/test/weekly-report\n');
    });

    // ── Start ngrok tunnel so QStash can reach localhost ──
    startNgrokTunnel();

  } catch (err) {
    console.error('❌ Failed to start:', err);
    process.exit(1);
  }
}

async function startNgrokTunnel() {
  try {
    const ngrok = await import('@ngrok/ngrok');
    const listener = await ngrok.forward({ addr: 3001, authtoken_from_env: true });
    const publicUrl = listener.url();
    console.log(`🌐 ngrok tunnel: ${publicUrl}`);
    console.log(`   QStash HITL URL  → ${publicUrl}/api/qstash/check-hitl`);
    console.log(`   QStash Report URL→ ${publicUrl}/api/qstash/weekly-report\n`);
    // Store for easy copy
    process.env.NGROK_PUBLIC_URL = publicUrl;
  } catch (err) {
    // ngrok auth token not set — skip silently, use /api/test/* routes instead
    if (err.message?.includes('authtoken') || err.message?.includes('NGROK_AUTHTOKEN')) {
      console.warn('⚠️  ngrok not configured (NGROK_AUTHTOKEN not set). Using /api/test/* for local testing.\n');
    } else {
      console.warn('⚠️  ngrok tunnel failed:', err.message);
    }
  }
}

start();
