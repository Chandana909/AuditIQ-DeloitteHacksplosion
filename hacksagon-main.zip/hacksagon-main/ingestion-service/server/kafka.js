import { Kafka } from 'kafkajs';

const TOPIC = 'auditiq.ingestion';
const BROKER = 'localhost:9092';

const kafka = new Kafka({
  clientId: 'auditiq-ingestion',
  brokers: [BROKER],
  retry: { initialRetryTime: 300, retries: 5 }
});

const producer = kafka.producer();
const consumer = kafka.consumer({ groupId: 'auditiq-ingestion-group' });
const admin = kafka.admin();

// ── In-memory job store ──────────────────────────────────────
export const jobs = new Map();

export function createJob(id, fileName, targetTable, totalRows) {
  const job = {
    id,
    fileName,
    targetTable,
    status: 'producing',
    totalRows,
    producedRows: 0,
    processedRows: 0,
    insertedRows: 0,
    skippedRows: 0,
    errorRows: 0,
    errors: [],
    createdAt: new Date().toISOString(),
    completedAt: null
  };
  jobs.set(id, job);
  return job;
}

export function getJob(id) { return jobs.get(id); }

export function getAllJobs() {
  return Array.from(jobs.values()).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ── Kafka lifecycle ──────────────────────────────────────────
export async function initKafka() {
  await admin.connect();
  const topics = await admin.listTopics();
  if (!topics.includes(TOPIC)) {
    await admin.createTopics({
      topics: [{ topic: TOPIC, numPartitions: 1, replicationFactor: 1 }]
    });
    console.log(`✅ Created Kafka topic: ${TOPIC}`);
  } else {
    console.log(`✅ Kafka topic already exists: ${TOPIC}`);
  }
  await admin.disconnect();
  await producer.connect();
  console.log('✅ Kafka producer connected');
}

export async function produceRows(jobId, targetTable, rows) {
  const job = jobs.get(jobId);

  const messages = rows.map((row, index) => ({
    key: targetTable,
    value: JSON.stringify({ jobId, targetTable, row, rowIndex: index, totalRows: rows.length })
  }));

  // Send in batches of 100 messages
  const BATCH = 100;
  for (let i = 0; i < messages.length; i += BATCH) {
    await producer.send({ topic: TOPIC, messages: messages.slice(i, i + BATCH) });
    if (job) job.producedRows = Math.min(i + BATCH, messages.length);
  }

  if (job) job.status = 'consuming';
}

export async function startConsumer(onMessage) {
  await consumer.connect();
  await consumer.subscribe({ topic: TOPIC, fromBeginning: false });

  await consumer.run({
    eachMessage: async ({ message }) => {
      try {
        const data = JSON.parse(message.value.toString());
        await onMessage(data);
      } catch (err) {
        console.error('Consumer error:', err.message);
      }
    }
  });
  console.log('✅ Kafka consumer started');
}
