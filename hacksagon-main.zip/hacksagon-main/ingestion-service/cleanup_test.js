import { pool } from './server/db.js';

async function cleanup() {
  console.log('Cleaning up test rows...');
  await pool.query(`DELETE FROM audit_results WHERE invoice_id LIKE 'TEST-%'`);
  await pool.query(`DELETE FROM invoices WHERE invoice_id LIKE 'TEST-%'`);
  
  // Verify
  const inv = await pool.query(`SELECT COUNT(*) FROM invoices`);
  const aud = await pool.query(`SELECT COUNT(*) FROM audit_results`);
  console.log(`invoices: ${inv.rows[0].count} (should be 51)`);
  console.log(`audit_results: ${aud.rows[0].count} (should be 50)`);
  console.log('✅ Test data cleaned up — database restored to original state');
  await pool.end();
}
cleanup();
