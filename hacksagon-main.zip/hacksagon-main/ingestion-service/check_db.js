import { pool } from './server/db.js';

const tables = ['invoices','purchase_orders','goods_receipts','approval_logs','vendor_master','audit_results'];

async function check() {
  console.log('=== DATABASE BASELINE ===');
  for (const t of tables) {
    const r = await pool.query(`SELECT COUNT(*) FROM ${t}`);
    console.log(`  ${t}: ${r.rows[0].count} rows`);
  }
  await pool.end();
}
check();
