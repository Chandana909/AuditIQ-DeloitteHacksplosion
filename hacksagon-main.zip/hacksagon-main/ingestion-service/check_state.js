import { pool } from './server/db.js';

const tables = ['invoices','purchase_orders','goods_receipts','approval_logs','vendor_master','audit_results'];
console.log('=== CURRENT DB STATE ===');
for (const t of tables) {
  const r = await pool.query(`SELECT COUNT(*) FROM ${t}`);
  console.log(`${t.padEnd(22)}: ${r.rows[0].count} rows`);
}
const hitl = await pool.query(`SELECT COUNT(*) FROM audit_results WHERE workflow_status='hitl_pending'`);
const auto = await pool.query(`SELECT COUNT(*) FROM audit_results WHERE workflow_status='auto_approved'`);
const pend = await pool.query(`SELECT COUNT(*) FROM audit_results WHERE risk_rating='Pending' OR risk_rating IS NULL`);
const high = await pool.query(`SELECT COUNT(*) FROM audit_results WHERE risk_rating IN ('HIGH','CRITICAL')`);
console.log('\n--- audit_results breakdown ---');
console.log(`hitl_pending : ${hitl.rows[0].count}`);
console.log(`auto_approved: ${auto.rows[0].count}`);
console.log(`high/critical: ${high.rows[0].count}`);
console.log(`risk Pending : ${pend.rows[0].count}`);
await pool.end();
